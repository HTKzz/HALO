package com.asia.constant;

public enum Role {
	USER, ADMIN, COMPANY
}
