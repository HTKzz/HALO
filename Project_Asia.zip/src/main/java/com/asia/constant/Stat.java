package com.asia.constant;

public enum Stat {
	회원, 블랙, 탈퇴
}
