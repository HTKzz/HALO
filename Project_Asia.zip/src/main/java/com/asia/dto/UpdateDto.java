package com.asia.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class UpdateDto {

	private String A1;
	private String A2;
	private String A3;
	private String A4;
	private String A5;
	private String A6;
	private String A7;
	private String A8;
	private String A9;
	private String A10;
	private String A11;
	private String A12;
	private String A13;
	private String A14;
	private String A15;
	private String A16;
	private String A17;
	private String A18;
	private String A19;
	private String A20;
	private String A21;
	private String A22;
	private String A23;
	private String A24;
	private String A25;
	private String A26;
	private String A27;
	private String A28;
	private String A29;
	private String A30;
	private String A31;
	private String A32;
	private String A33;
	private String A34;
	private String A35;
	private String A36;
	private String A37;
	private String A38;
	private String A39;
	private String A40;
	private String A41;
	private String A42;
	private String A43;
	private String A44;
	private String A45;
	private String A46;
	private String A47;
	private String A48;
	
}
