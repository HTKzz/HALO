package com.asia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AsiaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AsiaApplication.class, args);
	}

}
