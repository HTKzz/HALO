package com.asia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AsiaApplicationTests {

	@Test
	void contextLoads() {
	}

}
